package com.example.carappraisal.api

object BaseUrl {
    const val URL_API = "http://34.101.215.128:7000/"
}