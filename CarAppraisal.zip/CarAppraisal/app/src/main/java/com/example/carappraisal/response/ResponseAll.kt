package com.example.carappraisal.response

data class ResponseAll(
    val msg : String,
    val type: String
)
